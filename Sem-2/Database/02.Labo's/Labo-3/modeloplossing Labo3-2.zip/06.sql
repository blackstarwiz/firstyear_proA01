select Artiest
from Liedjes
where Artiest like '%E%';
