select Titel
from Liedjes
where not (Titel like '%O%'); -- mag ook met NOT LIKE
