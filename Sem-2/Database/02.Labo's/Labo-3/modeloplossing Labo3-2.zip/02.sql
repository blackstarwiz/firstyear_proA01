set sql_safe_updates = 0;
update Geboortes
set GewichtInKilogram = 2.8
where Voornaam = 'Thijs' and Familienaam = 'Verbeeck';
set sql_safe_updates = 1;
