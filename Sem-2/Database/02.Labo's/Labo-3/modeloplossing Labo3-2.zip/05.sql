select concat(Artiest, ' - ', Titel, '.mp3') as Filenaam
from Liedjes;
