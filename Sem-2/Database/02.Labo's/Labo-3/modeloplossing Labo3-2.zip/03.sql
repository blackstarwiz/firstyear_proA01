set sql_safe_updates = 0;
update Liedjes
set AantalVerkocht = 10 * AantalVerkocht;
set sql_safe_updates = 1;
