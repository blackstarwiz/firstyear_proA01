select *
from Geboortes
where TijdstipGeboorte < '1996-01-01 00:00:00' and GewichtInKilogram <= 3;
