set sql_safe_updates = 0;
update Geboortes
set Familienaam = concat(substring(Familienaam, 1, 1), '.');
set sql_safe_updates = 1;
