﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oefening
{
    internal class Evaluation
    {

        public static void Menu()
        {
            Console.WriteLine("Kies een van de onderstaande opties:\n1 - Resultaat\n2 - Wiskunde\n3 - TekstSpel\n4 - Einde");


            int optie = int.Parse(Console.ReadLine());
            switch (optie)
            {
                case 1:
                    Evaluation.Result();
                    break;
                case 2:
                    Evaluation.Mathematics();
                    break;
                case 3:
                    Evaluation.TextGame();
                    break;
                case 4:
                    Console.WriteLine("Tot ziens.");
                    break;
                default:
                    Console.WriteLine("Ongeldige keuze");
                    Menu();
                    break;
            }
        }
        //wachtwoord toest.ap.be: kopje
        public static void Result()
        {
            string antwoord = "ja";
            int countGes = 0;
            int count_NietGeslaagd = 0;
            int result = 0;
            Console.Write("Op hoeveel punten staat het examen?: ");
            int punten = int.Parse(Console.ReadLine());
                
            do
            {
                
                Console.Write("Resultaat: ");
                result = int.Parse(Console.ReadLine());

                if(result >= punten / 2)
                {
                    Console.WriteLine("Geslaagd!");
                    countGes++;
                }
                else
                {
                    Console.WriteLine("Niet Geslaagd!");
                    count_NietGeslaagd++;
                }
                Console.Write("Nog resultaten (ja of nee): ");
                antwoord = Console.ReadLine();
            } while (antwoord == "ja" | antwoord == "JA");

            double gemiddelde = (countGes + count_NietGeslaagd)/punten;

            Console.WriteLine($"Er zijn {countGes} studenten Geslaagd en {count_NietGeslaagd} niet geslaagd\nHet gemiddelde resultaat is {gemiddelde} op {punten}");
        }



        public static void Mathematics()
        {
            Console.WriteLine("Wat wil je bereken (A) de som of (B) het resultaat van een vermenigvuldiging berekenen?");
            Console.Write("Keuze A/B: ");
            string antwoord = Console.ReadLine();
            int start = 0;
            int end = 0;
            int result = 0;


            if (antwoord == "a" | antwoord == "A")
            {
                Console.Write("Startgetal:");
                start = int.Parse(Console.ReadLine());
                Console.Write("Eindgetal:");
                end = int.Parse(Console.ReadLine());
                int count = start;
                int hulp = start;
                do
                {
                    count++;
                    result += hulp + count;
                    hulp = result;
                } while (count != end);

                Console.WriteLine($"De som van de getallen {start} en {end} is {result}");
            }
            else
            {
                Console.Write("Startgetal:");
                start = int.Parse(Console.ReadLine());
                Console.Write("Eindgetal:");
                end = int.Parse(Console.ReadLine());
                int count = start;
                int hulp = start;


                do
                {
                    count++;
                    result += hulp * count;
                    hulp = result;

                } while (count != end);
                Console.WriteLine($"Het rusltaat van de vermenigvuldiging van de getallen {start} tot {end} is {result}");
            }
        }



        public static void TextGame()
        {
            Console.Write("Wat wil je omdraaien?:");
            string woord = Console.ReadLine();
            string[] LettersArray = new string[woord.Length];
            string result = "";
            
            for(int i=woord.Length; i<= woord.Length; )
            {
                --i;
                if (i > -1) {
                    result += woord[i].ToString();
                }
                else
                {
                    Console.WriteLine(result);
                    break;
                }
                
            }
        }
    }


   
}
